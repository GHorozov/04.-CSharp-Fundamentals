﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Exam_07August2016.BusinessLayer.Constracts.Core
{
    public interface IEngine
    {
        void Run();
    }
}
