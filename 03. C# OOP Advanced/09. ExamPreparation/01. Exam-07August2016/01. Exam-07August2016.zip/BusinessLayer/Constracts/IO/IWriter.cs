﻿namespace _01.Exam_07August2016.BusinessLayer.Constracts.IO
{
    public interface IWriter
    {
        void GatherOutput(string outputToGather);

        void WriteGatherOutput();
    }
}
