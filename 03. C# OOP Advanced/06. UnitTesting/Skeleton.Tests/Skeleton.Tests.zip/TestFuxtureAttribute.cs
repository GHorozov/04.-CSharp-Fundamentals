﻿using System;

internal class TestFuxtureAttribute : Attribute
{
}