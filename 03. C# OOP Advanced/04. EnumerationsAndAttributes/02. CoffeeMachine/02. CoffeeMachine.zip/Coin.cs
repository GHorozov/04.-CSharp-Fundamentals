﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum Coin
{
    Zero,
    One,
    Two,
    Five = 5,
    Ten = 10,
    Twenty = 20,
    Fifty = 50
}

