﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public enum CoffeePrice
{
    Small = 50, //(50c)
    Normal = 100, //(100c)
    Double = 200 //(200c)
}

