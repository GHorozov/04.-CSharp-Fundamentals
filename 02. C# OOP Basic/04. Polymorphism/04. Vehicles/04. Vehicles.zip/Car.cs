﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Car : Vehicles
{
    
    public Car(double fuelQuantity, double fuelConsumption, double airConditionFuel) : base(fuelQuantity, fuelConsumption, airConditionFuel)
    {
    }
}

