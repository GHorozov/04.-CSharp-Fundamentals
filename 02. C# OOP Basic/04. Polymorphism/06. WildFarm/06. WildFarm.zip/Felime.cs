﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public abstract class Felime : Mammal
{
    public Felime(string type, string name, double weight, string livingRegion) : base(type, name, weight, livingRegion)
    {

    }
}

