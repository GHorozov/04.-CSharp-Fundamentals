﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class StackOfStrings
{
    private List<string> date;
    

    public void Push(string item)
    {
        
    }

    public string Pop()
    {
        return "";
    }

    public string Peek()
    {
        return "";
    }

    public bool IsEmpty()
    {
        return true;
    }
}

