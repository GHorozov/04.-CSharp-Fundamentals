﻿using System;
using System.Collections.Generic;

public class HarvesterFactory
{
    public Harvester Get(List<string> arguments)
    {
        string type = arguments[1];
        string id = arguments[2];
        double oreOutput = double.Parse(arguments[3]);
        double energyRequirement = double.Parse(arguments[4]);

        switch (type)
        {
            case "Sonic":
                return new SonicHarvester(id, oreOutput, energyRequirement, int.Parse(arguments[5]));

            case "Hammer":
                return new HammerHarvester(id, oreOutput, energyRequirement);

            default:
                throw new ArgumentException("Harvester creation error.");
        }
    }
}
    

